<?php
// public/api/fetch_books.php

// Composer autoload
require __DIR__ . '/../../vendor/autoload.php';

// 本体ロジック
require __DIR__ . '/../../src/fetch_books.php';